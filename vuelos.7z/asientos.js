const AsientosJson = [
    {
        fila: "30",
        asientos: ["C", "D", "E", "F", "G"]
    },
    {
        fila: "31",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "32",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "33",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "34",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "35",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "36",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "37",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "38",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "39",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "40",
        asientos: ["A", "B", "C", "D", "E", "F", "G", "H", "J"]
    },
    {
        fila: "41",
        asientos: ["A", "B", "C", "D", "F", "G", "H", "J"]
    },
    {
        fila: "42",
        asientos: ["A", "B", "C", "D", "F", "G", "H", "J"]
    },
    {
        fila: "43",
        asientos: ["A", "B", "C", "D", "F", "G", "H", "J"]
    },
    {
        fila: "44",
        asientos: ["C", "D", "F", "G"]
    },
    {
        fila: "45",
        asientos: ["C", "D", "F", "G"]
    }
];
